<?php 
	session_start();
	$title = "FTU calendar";
	$title_logo = array('FTU ','Calendar' );
	$favicon = './dist/img/avatar5.png';
?>