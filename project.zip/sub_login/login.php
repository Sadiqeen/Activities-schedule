<li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="modal" data-target="#modal-login">
            <i class="fa fa-lg fa-lock"></i>
            <span class="hidden-xs">Log in</span>
          </a>
        </li>