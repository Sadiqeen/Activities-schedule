    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">

        <?php
          isset($_SESSION['id'])?  require './sub_login/dashboard.php' : require './sub_login/login.php' ;
        ?>

        

      </ul>
    </div>