<div class="modal fade" id="modal-dluser">
    <div class="modal-dialog" >
        <div class="modal-content">
            <div class="modal-body">
                <h3 class="text-center"><b>Please confirm delete.</b></h3><hr>
                    <!-- id -->
                    <input type="text" value="" id="id_delete_user" hidden>
                    <div class="form-group">
                        <button class="btn btn-block btn-danger" onclick="delete_user();">Confirm</button>
                    </div>
            </div>
        </div>
    </div>
</div>