<?php 
    echo password_hash('20121996',PASSWORD_DEFAULT);