<div class="modal fade" id="modal-dlevent">
    <div class="modal-dialog" >
        <div class="modal-content">
            <div class="modal-body">
                <h3 class="text-center"><b>Please confirm delete.</b></h3><hr>
                    <!-- id -->
                    <input type="text" value="" id="id_delete_event" hidden>
                    <div class="form-group">
                        <button class="btn btn-block btn-danger" onclick="delete_acvity();">Confirm</button>
                    </div>
            </div>
        </div>
    </div>
</div>