<table id="activities-table" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">id</th>
                      <th class="text-center">Tile</th>
                      <th class="text-center">Start</th>
                      <th class="text-center">End</th>
                      <th class="text-center">Faculty</th>
                      <th class="text-center">Department</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>

                  <tfoot>
                    <tr>
                      <th class="text-center">id</th>
                      <th class="text-center">Tile</th>
                      <th class="text-center">Start</th>
                      <th class="text-center">End</th>
                      <th class="text-center">Faculty</th>
                      <th class="text-center">Department</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </tfoot>
                </table>